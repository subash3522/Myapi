subash = {
    name:'subash', 
    age:'27'
}

module.exports = subash